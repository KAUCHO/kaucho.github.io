/* ================================================================
   KAUCHO PLUS — js/main.js
   Autor: KAUCHO PLUS
   Descripción: Lógica principal: productos, filtrado, idioma, UI
================================================================ */

'use strict';


/* ────────────────────────────────────────────────────────────────
   1. DATOS DE PRODUCTOS
   Cada producto tiene nombre en ES/EN e ícono representativo.
──────────────────────────────────────────────────────────────── */
const PRODUCTOS = [
  { es: 'Apoyo',              en: 'Support',                 icono: '🔩', modelos: 1 },
  { es: 'Bases',              en: 'Bases',                   icono: '🏗️', modelos: 4 },
  { es: 'Celda Cerrada',      en: 'Closed Cell',             icono: '🔲', modelos: 1 },
  { es: 'Dedos de Pollo',     en: 'Chicken Fingers',         icono: '🦾', modelos: 4 },
  { es: 'Defensa',            en: 'Fender',                  icono: '🛡️', modelos: 2 },
  { es: 'Codo Revés',         en: 'Reverse Elbow',           icono: '↩️', modelos: 1 },
  { es: 'Faldón',             en: 'Skirt',                   icono: '📐', modelos: 1 },
  { es: 'Impulsores',         en: 'Impellers',               icono: '⚙️', modelos: 4 },
  { es: 'Juntas',             en: 'Joints',                  icono: '🔗', modelos: 2 },
  { es: 'Perfil',             en: 'Profile',                 icono: '📏', modelos: 6 },
  { es: 'Pieza',              en: 'Part',                    icono: '🧩', modelos: 1 },
  { es: 'Placa',              en: 'Plate',                   icono: '🟫', modelos: 1 },
  { es: 'Poleas',             en: 'Pulleys',                 icono: '⭕', modelos: 1 },
  { es: 'Tanque',             en: 'Tank',                    icono: '🛢️', modelos: 2 },
  { es: 'Difusor',            en: 'Diffuser',                icono: '💨', modelos: 2 },
  { es: 'Eje de Caucho',      en: 'Rubber Shaft',            icono: '🪛', modelos: 1 },
  { es: 'Topes',              en: 'Stops',                   icono: '🛑', modelos: 2 },
  { es: 'Válvulas',           en: 'Valves',                  icono: '🚿', modelos: 1 },
  { es: 'Aleta',              en: 'Fin',                     icono: '🪁', modelos: 2 },
  { es: 'Malla Zaranda',      en: 'Screen Mesh',             icono: '🕸️', modelos: 1 },
  { es: 'Revestimientos',     en: 'Liners',                  icono: '🧱', modelos: 1 },
  { es: 'Spot',               en: 'Spot',                    icono: '🔵', modelos: 1 },
];


/* ────────────────────────────────────────────────────────────────
   2. TRADUCCIONES
   Objeto plano { clave: texto } para ES y EN.
   Las claves corresponden al atributo data-i18n del HTML.
──────────────────────────────────────────────────────────────── */
const TRADUCCIONES = {
  es: {
    /* Navegación */
    'nav-inicio':    'Inicio',
    'nav-nosotros':  'Nosotros',
    'nav-catalogo':  'Catálogo',
    'nav-contacto':  'Contacto',

    /* Hero */
    'hero-eyebrow':  'Especialistas en Caucho Industrial',
    'hero-title':    'Soluciones <em>Premium</em><br>en Caucho Industrial',
    'hero-text':     'Especialistas en minería, industria naval, construcción vial y procesos industriales complejos.',
    'hero-cta':      'Solicitar cotización',

    /* Nosotros */
    'sec-nosotros':    'Nuestra Empresa',
    'about-title':     'Quiénes Somos',
    'about-sub':       'Más de una década liderando el mercado ecuatoriano de caucho industrial.',
    'mission-title':   'Misión',
    'mission-text':    'Proveer soluciones integrales de caucho industrial de alta resistencia para optimizar la operatividad y extender la vida útil de los activos industriales.',
    'vision-title':    'Visión',
    'vision-text':     'Ser la empresa referente en soluciones de caucho industrial en Ecuador, reconocida por innovación, personalización y excelencia técnica.',
    'values-title':    'Valores',
    'values-text':     'Calidad, compromiso y precisión técnica son los pilares de cada pieza que fabricamos. Cada cliente recibe atención personalizada y asesoría especializada.',

    /* Estadísticas */
    'stat-productos':  'Productos',
    'stat-anos':       'Años de experiencia',
    'stat-custom':     'Personalizable',
    'stat-pais':       'Ecuador',

    /* Productos */
    'sec-productos':   'Catálogo',
    'prod-title':      'Nuestros Productos',
    'prod-sub':        'Piezas de caucho industrial de alta resistencia para cada necesidad.',
    'buscar-placeholder': 'Buscar producto...',
    'prod-badge':      'Alta resistencia',
    'prod-desc':       'Solución en caucho de alta resistencia para aplicaciones industriales exigentes.',
    'prod-modelos-1':  'Modelo único',
    'prod-modelos-n':  'modelos disponibles',

    /* Contacto */
    'sec-contacto':  'Contáctanos',
    'contact-title': 'Hablemos',
    'ci-title':      '¿Listo para una cotización?',
    'ci-text':       'Contáctenos y un especialista le asesorará sobre la solución de caucho más adecuada para su operación.',
    'lbl-name':      'Nombre',
    'lbl-company':   'Empresa',
    'lbl-email':     'Correo electrónico',
    'lbl-msg':       'Mensaje',
    'btn-send':      'Enviar por WhatsApp',

    /* Placeholders de formulario */
    'ph-name':    'Su nombre completo',
    'ph-company': 'Nombre de su empresa',
    'ph-email':   'correo@empresa.com',
    'ph-msg':     'Cuéntenos su necesidad...',
  },

  en: {
    /* Navegación */
    'nav-inicio':    'Home',
    'nav-nosotros':  'About',
    'nav-catalogo':  'Catalog',
    'nav-contacto':  'Contact',

    /* Hero */
    'hero-eyebrow':  'Industrial Rubber Specialists',
    'hero-title':    'Premium <em>Industrial</em><br>Rubber Solutions',
    'hero-text':     'Specialists in mining, marine industry, road construction and complex industrial processes.',
    'hero-cta':      'Request a quote',

    /* About */
    'sec-nosotros':    'Our Company',
    'about-title':     'Who We Are',
    'about-sub':       'Over a decade leading the Ecuadorian industrial rubber market.',
    'mission-title':   'Mission',
    'mission-text':    'Provide comprehensive high-resistance industrial rubber solutions to optimize operations and extend the useful life of industrial assets.',
    'vision-title':    'Vision',
    'vision-text':     'To be the leading industrial rubber solutions company in Ecuador, recognized for innovation, customization, and technical excellence.',
    'values-title':    'Values',
    'values-text':     'Quality, commitment, and technical precision are the pillars of every piece we manufacture. Each client receives personalized attention and specialized advice.',

    /* Stats */
    'stat-productos':  'Products',
    'stat-anos':       'Years of experience',
    'stat-custom':     'Customizable',
    'stat-pais':       'Ecuador',

    /* Products */
    'sec-productos':   'Catalog',
    'prod-title':      'Our Products',
    'prod-sub':        'High-resistance industrial rubber parts for every need.',
    'buscar-placeholder': 'Search product...',
    'prod-badge':      'High resistance',
    'prod-desc':       'High-resistance rubber solution for demanding industrial applications.',
    'prod-modelos-1':  'Single model',
    'prod-modelos-n':  'models available',

    /* Contact */
    'sec-contacto':  'Contact',
    'contact-title': "Let's Talk",
    'ci-title':      'Ready for a quote?',
    'ci-text':       'Contact us and a specialist will advise you on the most suitable rubber solution for your operation.',
    'lbl-name':      'Name',
    'lbl-company':   'Company',
    'lbl-email':     'Email address',
    'lbl-msg':       'Message',
    'btn-send':      'Send via WhatsApp',

    /* Form placeholders */
    'ph-name':    'Your full name',
    'ph-company': 'Your company name',
    'ph-email':   'email@company.com',
    'ph-msg':     'Tell us about your need...',
  },
};


/* ────────────────────────────────────────────────────────────────
   3. ESTADO GLOBAL
──────────────────────────────────────────────────────────────── */
let currentLang = 'es';


/* ────────────────────────────────────────────────────────────────
   4. RENDERIZAR PRODUCTOS
   Genera tarjetas de producto en el grid del catálogo.
   @param {string} lang   - Idioma activo ('es' | 'en')
   @param {string} filtro - Texto de búsqueda (puede ser vacío)
──────────────────────────────────────────────────────────────── */
function renderProductos(lang, filtro) {
  const grid   = document.getElementById('catalogo');
  const t      = TRADUCCIONES[lang];
  const query  = (filtro || '').toLowerCase().trim();

  // Filtrar por nombre en el idioma activo
  const visibles = PRODUCTOS.filter(function (p) {
    return p[lang].toLowerCase().includes(query);
  });

  // Vaciar el grid
  grid.innerHTML = '';

  // Mostrar mensaje si no hay resultados
  if (visibles.length === 0) {
    grid.innerHTML = '<p style="text-align:center;color:rgba(53,62,67,.5);grid-column:1/-1;padding:40px 0">No se encontraron productos.</p>';
    return;
  }

  // Construir cada tarjeta
  visibles.forEach(function (producto) {
    const nombre  = producto[lang];
    const modelos = producto.modelos;

    // Texto de modelos según cantidad
    const modelosTexto = modelos === 1
      ? t['prod-modelos-1']
      : modelos + ' ' + t['prod-modelos-n'];

    // Crear elemento
    const card = document.createElement('article');
    card.className = 'product-card';
    card.setAttribute('role', 'listitem');

    card.innerHTML =
      '<div class="product-card__icon" aria-hidden="true">' + producto.icono + '</div>' +
      '<h3 class="product-card__title">' + nombre + '</h3>' +
      '<p class="product-card__desc">' + t['prod-desc'] + '</p>' +
      '<span class="product-card__badge">' + t['prod-badge'] + ' · ' + modelosTexto + '</span>';

    grid.appendChild(card);
  });
}


/* ────────────────────────────────────────────────────────────────
   5. FILTRAR PRODUCTOS
   Llamado por el input de búsqueda (event onkeyup en HTML).
──────────────────────────────────────────────────────────────── */
function filtrar() {
  var input = document.getElementById('buscar');
  renderProductos(currentLang, input.value);
}


/* ────────────────────────────────────────────────────────────────
   6. CAMBIAR IDIOMA
   Actualiza todos los textos del DOM con data-i18n,
   los placeholders del formulario y re-renderiza productos.
   @param {string} lang - 'es' | 'en'
──────────────────────────────────────────────────────────────── */
function setLanguage(lang) {
  currentLang = lang;
  var t = TRADUCCIONES[lang];

  /* -- Actualizar botones activos -- */
  document.querySelectorAll('.lang-btn').forEach(function (btn, index) {
    var btnLang = index === 0 ? 'es' : 'en';
    btn.classList.toggle('lang-btn--active', btnLang === lang);
  });

  /* -- Actualizar todos los elementos con data-i18n -- */
  document.querySelectorAll('[data-i18n]').forEach(function (el) {
    var clave = el.getAttribute('data-i18n');
    if (!t[clave]) return;

    // Los inputs y textareas actualizan el placeholder
    if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
      el.placeholder = t[clave];
    } else {
      // innerHTML para permitir <em> y <br> en títulos
      el.innerHTML = t[clave];
    }
  });

  /* -- Actualizar placeholder del buscador -- */
  var inputBuscar = document.getElementById('buscar');
  if (inputBuscar) {
    inputBuscar.placeholder = t['buscar-placeholder'];
  }

  /* -- Actualizar placeholders del formulario por id -- */
  var placeholders = {
    inputName:    t['ph-name'],
    inputCompany: t['ph-company'],
    inputEmail:   t['ph-email'],
    inputMsg:     t['ph-msg'],
  };
  Object.keys(placeholders).forEach(function (id) {
    var el = document.getElementById(id);
    if (el) el.placeholder = placeholders[id];
  });

  /* -- Re-renderizar catálogo con el nuevo idioma -- */
  var filtroActual = inputBuscar ? inputBuscar.value : '';
  renderProductos(lang, filtroActual);
}


/* ────────────────────────────────────────────────────────────────
   7. HEADER AL HACER SCROLL
   Agrega/quita clase .header--scrolled para reducir padding.
──────────────────────────────────────────────────────────────── */
function manejarScroll() {
  var header = document.getElementById('header');
  if (!header) return;

  if (window.scrollY > 60) {
    header.classList.add('header--scrolled');
  } else {
    header.classList.remove('header--scrolled');
  }
}


/* ────────────────────────────────────────────────────────────────
   8. FORMULARIO DE CONTACTO
   Abre WhatsApp con el mensaje pre-rellenado.
──────────────────────────────────────────────────────────────── */
function manejarFormulario(evento) {
  evento.preventDefault();

  var nombre  = document.getElementById('inputName').value.trim();
  var empresa = document.getElementById('inputCompany').value.trim();
  var correo  = document.getElementById('inputEmail').value.trim();
  var mensaje = document.getElementById('inputMsg').value.trim();

  if (!nombre || !correo || !mensaje) {
    alert(currentLang === 'es'
      ? 'Por favor complete los campos obligatorios (Nombre, Correo y Mensaje).'
      : 'Please fill in the required fields (Name, Email and Message).'
    );
    return;
  }

  // Construir mensaje para WhatsApp
  var texto =
    '¡Hola KAUCHO PLUS!\n\n' +
    'Nombre: ' + nombre + '\n' +
    (empresa ? 'Empresa: ' + empresa + '\n' : '') +
    'Correo: ' + correo + '\n\n' +
    'Mensaje:\n' + mensaje;

  var url = 'https://wa.me/593991863635?text=' + encodeURIComponent(texto);
  window.open(url, '_blank', 'noopener');
}


/* ────────────────────────────────────────────────────────────────
   9. INICIALIZACIÓN
   Se ejecuta cuando el DOM está listo.
──────────────────────────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', function () {

  // Renderizar productos en español (idioma por defecto)
  renderProductos('es', '');

  // Escuchar scroll para el header
  window.addEventListener('scroll', manejarScroll, { passive: true });

  // Conectar formulario de contacto
  var formulario = document.getElementById('contactForm');
  if (formulario) {
    formulario.addEventListener('submit', manejarFormulario);
  }

  // Conectar input de búsqueda
  var inputBuscar = document.getElementById('buscar');
  if (inputBuscar) {
    inputBuscar.addEventListener('input', filtrar);
  }

});
