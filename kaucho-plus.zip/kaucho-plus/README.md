# KAUCHO PLUS 🏭

Sitio web oficial de **KAUCHO PLUS** — Soluciones Premium en Caucho Industrial para Ecuador.

---

## 📁 Estructura del proyecto

```
kaucho-plus/
├── index.html        # Estructura HTML semántica
├── css/
│   └── style.css     # Todos los estilos (variables, componentes, responsive)
├── js/
│   └── main.js       # Lógica JS (productos, idioma, formulario, scroll)
└── README.md
```

---

## 🚀 Cómo usar

### Opción 1 — Abrir directo
Abre `index.html` en tu navegador. No necesita servidor ni dependencias.

### Opción 2 — Servidor local (recomendado)
```bash
# Con Python
python -m http.server 8000

# Con Node.js (npx)
npx serve .
```
Luego visita `http://localhost:8000`

---

## ✨ Funcionalidades

| Función | Descripción |
|---|---|
| 🌐 Bilingüe ES / EN | Todos los textos se traducen al cambiar de idioma |
| 🔍 Buscador de productos | Filtra el catálogo en tiempo real |
| 📱 Formulario → WhatsApp | El formulario arma un mensaje y abre WhatsApp |
| 📜 Header al scroll | El header se comprime al bajar la página |
| 💬 Botón flotante | Acceso directo a WhatsApp desde cualquier sección |

---

## 🎨 Tecnologías

- **HTML5** semántico (sin frameworks)
- **CSS3** con variables (`--color-dorado`, etc.) y animaciones puras
- **JavaScript ES5/ES6** vanilla (sin jQuery ni librerías)
- **Google Fonts** — Bebas Neue + DM Sans

---

## 🖊️ Agregar o editar productos

Edita el array `PRODUCTOS` en `js/main.js`:

```js
{ es: 'Nombre en español', en: 'Name in English', icono: '⚙️', modelos: 2 },
```

- `es` / `en` — nombre del producto en cada idioma
- `icono` — emoji representativo
- `modelos` — número de variantes (1 = "Modelo único")

---

## 📞 Contacto

- **WhatsApp:** +593 99 186 3635
- **País:** Ecuador 🇪🇨

---

© 2026 KAUCHO PLUS — Todos los derechos reservados
